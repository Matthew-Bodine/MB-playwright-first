
from pages.login_page import LoginPage
from playwright.sync_api import expect


def test_inventory_page_displays_products(page):
    login = LoginPage(page)

    login.open()
    login.login("standard_user", "secret_sauce")

    expect(page).to_have_url(
        "https://www.saucedemo.com/inventory.html"
    )
    expect(page.locator(".inventory_item")).to_have_count(6)
