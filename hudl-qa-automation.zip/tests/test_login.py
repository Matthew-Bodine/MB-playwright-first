
from playwright.sync_api import expect

from pages.login_page import LoginPage
from pages.inventory_page import InventoryPage


def test_valid_login(page):
    login = LoginPage(page)
    inventory = InventoryPage(page)

    login.open()
    login.login("standard_user", "secret_sauce")

    inventory.expect_loaded()
    expect(page).to_have_url(
        "https://www.saucedemo.com/inventory.html"
    )


def test_invalid_login(page):
    login = LoginPage(page)

    login.open()
    login.login("invalid_user", "wrong_password")

    login.expect_error(
        "Username and password do not match"
    )
