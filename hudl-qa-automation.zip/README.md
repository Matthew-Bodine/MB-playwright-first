UI Test Automation with Python

This project is a small automated testing suite built with Python, pytest, and Playwright. I built it to get hands-on experience with UI testing and browser automation.

The tests run against SauceDemo, a sample e-commerce website designed for practicing software testing.

Tests

The suite currently tests three scenarios: successful login, failed login with invalid credentials, and the inventory page displaying all six products.

Tools

Python, pytest, Playwright, and pytest-html.

Project Structure

The tests directory contains the automated tests, while pages contains classes for interacting with the website. Browser setup and cleanup are handled in conftest.py, and config.py contains the test configuration.

Running the Tests

Install the dependencies using:

python -m pip install -r requirements.txt
python -m playwright install chromium

Run the test suite with:

python -m pytest

To generate an HTML report, run:

python -m pytest --html=reports/report.html --self-contained-html

The report will be saved to reports/report.html.

What I Learned

Building this project gave me practical experience with browser automation, positive and negative testing, pytest fixtures, assertions, and organizing tests using the Page Object Model.

This is a small learning project focused on understanding the fundamentals of UI test automation.