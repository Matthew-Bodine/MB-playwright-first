import pytest
from playwright.sync_api import sync_playwright

from config import BROWSER, HEADLESS, DEFAULT_TIMEOUT


@pytest.fixture
def page():
    with sync_playwright() as playwright:
        browser_type = getattr(playwright, BROWSER)

        browser = browser_type.launch(
            headless=HEADLESS
        )

        context = browser.new_context()
        browser_page = context.new_page()
        browser_page.set_default_timeout(DEFAULT_TIMEOUT)

        try:
            yield browser_page
        finally:
            context.close()
            browser.close()
