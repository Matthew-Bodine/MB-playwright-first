from playwright.sync_api import Page, expect


class InventoryPage:
    def __init__(self, page: Page):
        self.page = page

        self.page_title = page.get_by_text(
            "Products",
            exact=True
        )

    def expect_loaded(self):
        expect(self.page_title).to_be_visible()